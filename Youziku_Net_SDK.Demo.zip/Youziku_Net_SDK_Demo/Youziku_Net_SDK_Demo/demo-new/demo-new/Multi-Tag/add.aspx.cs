﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.IO;

using System.Text;
using Youziku.Client;
using Youziku.Param.Batch;
using Youziku.Param;

namespace API_demo
{
    public partial class add : System.Web.UI.Page
    {
        static readonly IYouzikuServiceClient youzikuClient = new YouzikuServiceClient("xxx");
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
            string url = Server.MapPath("news.xml");

            //收集新闻数据
            string news_title = this.title.Text.ToString();
            string news_author = this.author.Text.ToString();
            string news_ly = this.ly.Text.ToString();
            string news_content = this.content.Text.ToString();
            string news_adddate = DateTime.Now.ToString();
            //添加新记录
            try
            {
                //XML数据库操作
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(url); 
                XmlNode root = xmlDoc.SelectSingleNode("xinwen");                
                XmlElement news = xmlDoc.CreateElement("news");
                string id;                
                if (root.HasChildNodes)
                {
                    id = Convert.ToString(Convert.ToInt32(root.LastChild.FirstChild.InnerText) + 1);
                }
                else
                {
                    id = "1";
                }
                //将获取到的数据插入到数据库中                
                XmlElement id2 = xmlDoc.CreateElement("news_id");//设置ID                
                id2.InnerText = id;
                news.AppendChild(id2);

                XmlElement title = xmlDoc.CreateElement("news_title");//保存标题                
                title.InnerText = news_title;
                news.AppendChild(title);

                XmlElement author = xmlDoc.CreateElement("news_author");//保存作者
                author.InnerText = news_author;
                news.AppendChild(author);

                XmlElement ly = xmlDoc.CreateElement("news_ly");//保存来源
                ly.InnerText = news_ly;
                news.AppendChild(ly);

                XmlElement content = xmlDoc.CreateElement("news_content");//保存内容
                content.InnerText = news_content;
                news.AppendChild(content);

                XmlElement adddate = xmlDoc.CreateElement("news_adddate");//保存时间
                adddate.InnerText = news_adddate;
                news.AppendChild(adddate);

                //收集文字准备调用接口，每个标签就是一个提交项(本示例将为不同的标签设置不同的字体，实际应用可根据自身需要设置合适的字体)

                var cusParam = new BatchFontFaceParam();
                cusParam.Tags.Add(new FontFaceParam { AccessKey = "xxx", Content = news_title, Tag = ".title" });//标题(每个用户的accesskey是不同的，要对应apikey)
                cusParam.Tags.Add(new FontFaceParam { AccessKey = "xxx", Content = news_author, Tag = ".author" });//作者
                cusParam.Tags.Add(new FontFaceParam { AccessKey = "xxx", Content = news_ly, Tag = ".ly" });        //来源
                cusParam.Tags.Add(new FontFaceParam { AccessKey = "xxx", Content = news_content, Tag = ".content" });//正文
               


                //调用接口

                var result = youzikuClient.GetBatchFontFace(cusParam);

               
               

                //创建保存效果数据的字段(如果是非XML的数据库，那么下面这几个字段应该应该是在建表时就创建，一个文字字段[需要显示效果的字段]要配两个字段，一个用来保存fontfamily，一个用来保存@font-face)
                XmlElement Xfontfacetitle = xmlDoc.CreateElement("fontfacetitle");
                XmlElement Xfontfaceauthor = xmlDoc.CreateElement("fontfaceauthor");
                XmlElement Xfontfacely = xmlDoc.CreateElement("fontfacely");
                XmlElement Xfontfacecontent = xmlDoc.CreateElement("fontfacecontent");

                XmlElement Xfontfamilytitle = xmlDoc.CreateElement("fontfamilytitle");
                XmlElement Xfontfamilyauthor = xmlDoc.CreateElement("fontfamilyauthor");
                XmlElement Xfontfamilyly = xmlDoc.CreateElement("fontfamilyly");
                XmlElement Xfontfamilycontent = xmlDoc.CreateElement("fontfamilycontent");


                //遍历@font-face序列(这个序列是与上面提交参数（tags字典）对应的，一个标签对应一个@font-face)将标签的效果数据保存到对应的字段
                foreach (var s in result.FontfaceList)
                {
                    switch (s.Tag)
                    {
                        case ".title":
                            Xfontfacetitle.InnerText = s.FontFace;//保存@font-face
                            news.AppendChild(Xfontfacetitle);

                            Xfontfamilytitle.InnerText = s.FontFamily;//保存FontFamily
                            news.AppendChild(Xfontfamilytitle);
                            break;
                        case ".author":
                            Xfontfaceauthor.InnerText = s.FontFace;//保存@font-face
                            news.AppendChild(Xfontfaceauthor);

                            Xfontfamilyauthor.InnerText = s.FontFamily;//保存FontFamily
                            news.AppendChild(Xfontfamilyauthor);
                            break;
                        case ".ly":
                            Xfontfacely.InnerText = s.FontFace;//保存@font-face
                            news.AppendChild(Xfontfacely);

                            Xfontfamilyly.InnerText = s.FontFamily;//保存FontFamily
                            news.AppendChild(Xfontfamilyly);
                            break;
                        case ".content":
                            Xfontfacecontent.InnerText = s.FontFace;//保存@font-face
                            news.AppendChild(Xfontfacecontent);

                            Xfontfamilycontent.InnerText = s.FontFamily;//保存FontFamily
                            news.AppendChild(Xfontfamilycontent);
                            break;
                        default:
                            break;
                    }

                }

                //保存数据
                root.AppendChild(news);
                xmlDoc.Save(url);

                Response.Redirect("list.aspx");
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            } 
        }

        

      

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}