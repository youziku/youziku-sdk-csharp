﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.IO;

using System.Text;
using Youziku.Client;
using Youziku.Param.Batch;
using Youziku.Param;

namespace demo_new.User_custom
{
    public partial class add : System.Web.UI.Page
    {
        static readonly IYouzikuServiceClient youzikuClient = new YouzikuServiceClient("xxx");

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            string url = Server.MapPath("news.xml");

            //收集新闻数据
            string news_title = this.title.Text.ToString();
            string news_author = this.author.Text.ToString();
            string news_ly = this.ly.Text.ToString();
            string news_content = this.content.Text.ToString();
            string news_adddate = DateTime.Now.ToString();
            //添加新记录
            try
            {
                //XML数据库操作
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(url);
                XmlNode root = xmlDoc.SelectSingleNode("xinwen");
                XmlElement news = xmlDoc.CreateElement("news");
                string id;
                if (root.HasChildNodes)
                {
                    id = Convert.ToString(Convert.ToInt32(root.LastChild.FirstChild.InnerText) + 1);
                }
                else
                {
                    id = "1";
                }
                //将获取到的数据插入到数据库中                
                XmlElement id2 = xmlDoc.CreateElement("news_id");//设置ID                
                id2.InnerText = id;
                news.AppendChild(id2);

                XmlElement title = xmlDoc.CreateElement("news_title");//保存标题                
                title.InnerText = news_title;
                news.AppendChild(title);

                XmlElement author = xmlDoc.CreateElement("news_author");//保存作者
                author.InnerText = news_author;
                news.AppendChild(author);

                XmlElement ly = xmlDoc.CreateElement("news_ly");//保存来源
                ly.InnerText = news_ly;
                news.AppendChild(ly);

                XmlElement content = xmlDoc.CreateElement("news_content");//保存内容
                content.InnerText = news_content;
                news.AppendChild(content);

                XmlElement adddate = xmlDoc.CreateElement("news_adddate");//保存时间
                adddate.InnerText = news_adddate;
                news.AppendChild(adddate);
                


                //收集文字准备调用接口，每个标签就是一个提交项(本示例将为不同的标签设置不同的字体，实际应用可根据自身需要设置合适的字体)

                var cusParam = new BatchCustomPathWoffFontFaceParam();
                cusParam.Datas.Add(new CustomPathFontFaceParam { AccessKey = "xxx", Content = news_title, Url = "apidemo/" + id + "/title" });//标题(每个用户的accesskey是不同的，要对应apikey)
                cusParam.Datas.Add(new CustomPathFontFaceParam { AccessKey = "xxx", Content = news_author, Url = "apidemo/" + id + "/author" });//作者
                cusParam.Datas.Add(new CustomPathFontFaceParam { AccessKey = "xxx", Content = news_ly, Url = "apidemo/" + id + "/ly" });        //来源
                cusParam.Datas.Add(new CustomPathFontFaceParam { AccessKey = "xxx", Content = news_content, Url = "apidemo/" + id + "/content" });//正文
               
                           


                //调用接口
            
                var response4 = youzikuClient.GetCustomPathBatchWoffWebFont(cusParam);
                

                //保存数据
                root.AppendChild(news);
                xmlDoc.Save(url);

                Response.Redirect("list.aspx");
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            }
        }





        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}