﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.IO;

namespace API_demo
{
    public partial class show : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string url = Server.MapPath("news.xml");
            string news_id = Request.QueryString["news_id"];
            if (news_id == "")
            {
                Response.Redirect("news_manage.aspx");
            }
            else
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(url); //加载XML文档
                XmlNode root = xmlDoc.SelectSingleNode("xinwen/news[news_id ='" + news_id + "']");

                if (root != null)
                {
                    title.Text = root.ChildNodes[1].InnerText;
                    author.Text = root.ChildNodes[2].InnerText;
                    ly.Text = root.ChildNodes[3].InnerText;
                    content.Text = Server.HtmlEncode(root.ChildNodes[4].InnerText.ToString());
                    adddate.Text = root.ChildNodes[5].InnerText;

                    //获取所有标签的@font-face(font-family可以不用获取，因为@font-face已经将效果引入到对应的tab下面了，在列表里需要用到font-famiy)
                    string Strfontface = root.ChildNodes[6].InnerText + root.ChildNodes[8].InnerText + root.ChildNodes[10].InnerText + root.ChildNodes[12].InnerText;


                    System.Web.UI.LiteralControl style = new System.Web.UI.LiteralControl();
                    style.Text = "<style type=\"text/css\">" + Strfontface + "</style>";

                    this.Header.Controls.Add(style);
                }
            }
        }
    }
}