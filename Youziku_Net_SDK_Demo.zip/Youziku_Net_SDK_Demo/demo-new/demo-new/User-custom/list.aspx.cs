﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.IO;

namespace demo_new.User_custom
{
    public partial class list : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ReadXML();
            }
        }

        private void ReadXML()
        {
            string url = Server.MapPath("news.xml");//获得当前文件夹下的XML文件
            StreamReader sRead = new StreamReader(url, System.Text.Encoding.GetEncoding("GB2312"));
            //以一种特定的编码从字节流读取字符,必须要转化成GB2312读取才不能出乱码
            XmlDataDocument datadoc = new XmlDataDocument();//操作XML文档
            datadoc.DataSet.ReadXml(sRead);//将读取的字节流存到DataSet里面去
            if (datadoc.DataSet.Tables.Count > 0)
            {
                this.GridView1.DataSource = datadoc.DataSet.Tables[0].DefaultView;
                this.GridView1.DataBind();
            }
            datadoc = null;//清空对XML数据的操作
            sRead.Close();//关闭字节流的读取
        }
    }
}